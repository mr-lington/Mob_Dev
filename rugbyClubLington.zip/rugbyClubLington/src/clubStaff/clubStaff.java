package clubStaff;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *Creating the properties and constructor of the staff club
 * the properties are extended to other club staff
 * @author lington
 */
public abstract class clubStaff {
    // properties of clubStaff
    
    private String staffName;
    private int age;
    private int hiredDate;
    
    private clubStaffType type;
    private static int uniqIdNum = 300;
    
    
   //constructor
    public clubStaff (String staffName, int uniqIdNum, int age, int hiredDate, clubStaffType type){
        
        this.staffName = staffName;
        this.hiredDate = hiredDate;
        this.age = age;
        this.type = type;
        this.uniqIdNum = getuniqIdNum();
    }
    
    private int getuniqIdNum(){
        
        uniqIdNum++;
        return uniqIdNum;
    }
    
    
}
