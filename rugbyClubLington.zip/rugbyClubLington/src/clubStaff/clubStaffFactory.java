/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clubStaff;

import java.util.Random;

/**
 *
 * @author lington
 */
public class clubStaffFactory {
    
    
    public clubStaff getClubStaff() {
        
        Random r = new Random();
        clubStaffType[] types = clubStaffType.values();
        
        int number = r.nextInt(types.length);
        
        return getClubStaff(types[number]);
    }
    
    public clubStaff getClubStaff(clubStaffType type){
        
        return type.getClubStaff();
    }
    
}
