/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clubStaff;

/**
 *
 * @author lington
 */
public class massageTherapist extends clubStaff {
    
    public massageTherapist (String staffName, int uniqIdNum, int age, int hiredDate){
        super(staffName, uniqIdNum, age, hiredDate, clubStaffType.MASSAGETHERAPIST);
    }
    
}
