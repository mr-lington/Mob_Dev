/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clubStaff;

import generators.staffNameGenerator;
import java.util.Random;

/**
 *
 * @author lington
 */
public enum clubStaffType { // here the name of the staffs is randomly generated
    
    CHAIRPERSON {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new chairperson (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "chairperson"; //returns the chairperson
    }
},
    
    
    
    ACCOUNTANT {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new accountant (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "accountant"; //returns the accountant
   
    }
},
    
    
  CLUBADMINISTRATOR {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new clubAdministrator (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "clubAdministrator"; //returns the clubAdministrator
   
    }
},   
    
   DIRECTOROFRUGBY {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new directorOfRugby (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "directorOfRugby"; //returns the directorOfRugby
   
    }
}, 
  
   
   DOCTOR {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new doctor (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "doctor"; //returns the doctor
   
    }
},
   
   
   HEALTHSAFETYOFFICER {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new healthSafetyOfficer (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "healthSafetyOfficer"; //returns the healthSafetyOfficer
   
    }
},
   
   
   
    HONORARYSECRETARY {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new honorarySecretary (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
         return "honorarySecretary"; //returns the honorarySecretary
   
    }
},
    
    
    
   HONORARYTREASURER {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new honoraryTreasurer (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "honoraryTreasurer"; //returns the honoraryTreasurer
   
    }
},
   
   
   
   MASSAGETHERAPIST {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new massageTherapist (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "massageTherapist"; //returns the massageTherapist
   
    }
},
   
   
   PRESIDENT {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new president (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "president"; //returns the president
   
    }
},
   
  
   
 PRESSOFFICER {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new pressOfficer (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "pressOfficer"; //returns the press pressOfficer
   
    }
},
 


  VICECHAIRPERSON {
    
    @Override
    public clubStaff getClubStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int uniqIdNum = 0;
        int hiredDate = 1;
        return new viceChairperson (name, uniqIdNum, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "viceChairperson"; //returns the viceChairperson
   
    }
};
   
  protected staffNameGenerator sNameGenerator;
  public abstract clubStaff getClubStaff();
  public abstract String toString();
  
  
  //methord to randomly generate staff age
  private static int getAge() {
      
      Random r = new Random(); // random methord created
      
      return r.nextInt(70); //genarate the age until 70
  }
   
}
