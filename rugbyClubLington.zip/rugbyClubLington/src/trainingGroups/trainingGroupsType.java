/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainingGroups;

import generators.groupNameGenerator;
import java.util.Random;

/**
 *
 * @author lington
 */
public enum trainingGroupsType {
    
    TEAMA {
    
    @Override
    public trainingGroups getTrainingGroups() {
     
        this.pNameGenerator = new groupNameGenerator();
//        String groupsName = pNameGenerator.getPlayerNumGenerator();
        String groupId = "";
        int groups = 50;
        int uniqIdNum = 0;
        int playerNum =0;
        return new teamA ( groupId, groups, uniqIdNum);
        
    }
    
    @Override
    public String toString() {
        return "teamA"; //returns the teamA
    }
    
},
   
   TEAMB {
    
    @Override
    public trainingGroups getTrainingGroups() {
     
        this.pNameGenerator = new groupNameGenerator();
   //     String groupsName = pNameGenerator.getPlayerNumGenerator();
        String groupId = "";
        int groups = 50;
        int uniqIdNum = 0;
        int playerNum =0;
        return new teamB ( groupId, groups, uniqIdNum);
        
    }
    
    @Override
    public String toString() {
        return "teamB"; //returns the teamB
    }
    
},
   
   UNDER13TEAM {
    
    @Override
    public trainingGroups getTrainingGroups() {
     
        this.pNameGenerator = new groupNameGenerator();
    //    String groupsName = pNameGenerator.getPlayerNumGenerator();
        String groupId = "";
        int groups = 50;
        int uniqIdNum = 0;
        int playerNum =0;
        return new under13Team (groupId, groups, uniqIdNum );
        
    }
    
    @Override
    public String toString() {
        return "under13Team"; //returns the under13Team
    }
},
   
   WOMENTEAM {
    
    @Override
    public trainingGroups getTrainingGroups() {
     
        this.pNameGenerator = new groupNameGenerator();
      //  String groupsName = pNameGenerator.getPlayerNumGenerator();
        String groupId = "";
        int groups = 50;
        int uniqIdNum = 0;
        int playerNum =0;
        return new womenTeam ( groupId, groups, uniqIdNum);
        
    }
    
    @Override
    public String toString() {
        return "womenTeam"; //returns the teamA
    }
};
   
  protected groupNameGenerator pNameGenerator;
  public abstract trainingGroups getTrainingGroups();
  public abstract String toString();
  
  
  //methord to randomly generate user age
  private static int getGroupsName() {
      
      Random r = new Random(); // random methord created
      
      return r.nextInt(50); //genarate the age until 50 
  }
    
    
    
}
