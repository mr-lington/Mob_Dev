/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainingGroups;


/**
 *
 * @author lington
 */
public class trainingGroups {
    // properties of clubStaff
    
    private String groupName;
    private int groupId;
   
    private int groups;
    
    private final trainingGroupsType type;
    private static int uniqIdNum;
    
    
    
   //constructor
    public trainingGroups (String groupName,int groupId, int groups, trainingGroupsType type){
        
        this.groupName = groupName;
       
        this.groupId = groupId;
        this.type = type;
        this.groups = groups;
        
        
        
    }
    
    private int getuniqIdNum(){
        uniqIdNum++;
        return uniqIdNum;
    }
   
}
