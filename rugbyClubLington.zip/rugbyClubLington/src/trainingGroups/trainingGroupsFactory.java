/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainingGroups;

import java.util.Random;

/**
 *
 * @author lington
 */
public class trainingGroupsFactory {
    
    
   public trainingGroups getTrainingGroups() {
        
        Random r = new Random();
        trainingGroupsType[] types = trainingGroupsType.values();
        
        int number = r.nextInt(types.length);
        
       return getTrainingGroups(types[number]);
    }
    
    public trainingGroups getTrainingGroups(trainingGroupsType type){
        
       return type.getTrainingGroups();
    }
    
}