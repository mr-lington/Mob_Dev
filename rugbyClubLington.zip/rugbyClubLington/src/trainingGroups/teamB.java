/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainingGroups;

/**
 *
 * @author lington
 */
public class teamB extends trainingGroups{
    
    public teamB (String groupId, int groups, int playerNum) {
        
        super ( groupId, groups, playerNum, trainingGroupsType.TEAMB);
    }
    
}
