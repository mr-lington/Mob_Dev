/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rugbyclub;

import clubStaff.clubStaff;
import clubStaff.clubStaffFactory;
import coachingStaff.coachingStaff;
import coachingStaff.coachingStaffFactory;
import java.util.ArrayList;
import java.util.Random;
import trainingGroups.trainingGroups;
import trainingGroups.trainingGroupsFactory;

/**
 *
 * @author lington
 */
public class RugbyClub {
    
    /**
     * 
     * creating an array list for the for all the club staffs
     * creating array list for the coaching staffs separately
     * also creating an array list for the different training groups
     */

    private ArrayList<clubStaff> members;
    private ArrayList<coachingStaff> staffs;
    private ArrayList<trainingGroups> groups;
    
    //constructor
    public RugbyClub(){
        
        this.members = new ArrayList<clubStaff>();
        this.staffs  = new ArrayList<coachingStaff>();
        this.groups  = new ArrayList<trainingGroups>();
        
        admitMembers();
        admitStaffs();
        admitGroups();
        
        
        
    }
    
    
    public static void main(String[] args) {
        
        RugbyClub myClub = new RugbyClub();
        
        
        
    }
    
    private void admitMembers (){
        
        Random r = new Random(); //randomly select members of the club
        
        clubStaffFactory myClubStaffFactory = new clubStaffFactory(); //new object created for club staff
        
        for(int i = 0; i <11; i++){  //count the staff members
            
            clubStaff someClubStaff = myClubStaffFactory.getClubStaff();
            
            this.members.add(someClubStaff);
            
            
        }
        
       {
        
        System.out.println("\n****************** list of clubStaffs*****************\n");
        for(clubStaff CS :members){
            System.out.println(CS.toString());
        }
        
        System.out.println("\n*******************end list of clubStaff*****************\n");
    }

        
    }
    
    private void admitStaffs(){
        
        Random r = new Random(); // randomly select members specifically from from the coaching staffs
        
        coachingStaffFactory myCoachingStaffFactory = new coachingStaffFactory(); // new object created for coaching staffs
        
        for (int i = 0; i<23; i++){
            
             coachingStaff someCoachingStaff = myCoachingStaffFactory.getCoachingStaff();
             
             this.staffs.add(someCoachingStaff);
        }
        
        {
        
        System.out.println("\n****************** list of coachingStaffs*****************\n");
        for(coachingStaff CS :staffs){
            System.out.println(CS.toString());
        }
        
        System.out.println("\n*******************end list of coachingStaffs**************\n");
    }
        
    }
    
    private void admitGroups(){
        
        Random r = new Random(); // randomly select different training groups
        
        trainingGroupsFactory myTrainingGroupsFactory = new trainingGroupsFactory(); // new object created for Training groups
        
        for ( int i = 0; i<4; i++){
            
             trainingGroups someTrainingGroups = myTrainingGroupsFactory.getTrainingGroups();
             
             this.groups.add(someTrainingGroups);
             
        }
        
        {
        
        System.out.println("\n****************** list of trainingGroups*****************\n");
            
        for(trainingGroups TG : groups){
            System.out.println(TG.toString());
        }
        
        System.out.println("\n*******************end list of trainingGroups**************\n");
    }
        
    }
    
     
    
}
