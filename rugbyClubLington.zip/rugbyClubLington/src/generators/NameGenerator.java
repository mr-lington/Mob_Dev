/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generators;

import java.util.Random;

/**
 *
 * @author lington
 */
public class NameGenerator {
     
       //samples of first and last names to be randomly generated
    protected String [] FirstNames = {"Abigail", "Alexandra", "Angelina", "Austin", "Adrian", "Anthony", "Bobby", "Bruce", "Bryce", "Calvin" };
    
    protected String [] LaststNames = {"O’Sullivan", "O’Brien", "O’Connor", "O’Neill", "O’Reilly", "Lynch", "Quinn", "O’Carroll", "O’Connell", "O’Farrell" };
    
    public NameGenerator() {
        
        
    }
    
    public String getRandomName() {
        
        Random r = new Random(); //creating a method to randonly pick name
        
        //each selected first and last name has a length
        String firstName = FirstNames[r.nextInt(FirstNames.length)];
        String lastName = FirstNames[r.nextInt(FirstNames.length)];
        
        return (firstName + " " + lastName);  // return a first and last name
    }
    
}