/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generators;


import java.util.Random;

/**
 *the name of the staffs are generated randomly
 * first protected string is the first name and the second protected is the last name
 * @author lington
 */
public class staffNameGenerator  extends NameGenerator{

        private String[] staffFFirstNames = {"Jeff", "", "Sammy", "Faith", "Rachel", "Susan", "Cyntha", "Mario"};
	
	private String[] staffLastNames = {"brian" , "osas", "joseph", "jerry", "", "ade", "imade", "osazuwa", "osaretin", "Johhny", "Mcfish"};
	
	public staffNameGenerator() {
		
		//the first and last name of the staff is generated
		this.FirstNames = staffFFirstNames;
                        
		this.LaststNames = staffLastNames;
		
	}

    //public String getStaffNameGenerator() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
            
            
            

    

 