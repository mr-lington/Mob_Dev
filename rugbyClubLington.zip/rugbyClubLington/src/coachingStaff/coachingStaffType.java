/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coachingStaff;

import generators.staffNameGenerator;
import java.util.Random;

/**
 *
 * @author lington
 */
public enum coachingStaffType { // here the name of the coaching staffs is randomly generated
    
    HEADCOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new headCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "headCoach"; //returns the headCoach
    }
},
    
    ASSISTANTCOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new assistantCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "assistantCoach"; //returns the assistantCoach
    }
},
    
    ACADEMYCOACHDEVELOPMENTMANAGER {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new academyCoachDevelopmentManager (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "academyCoachDevelopmentManager"; //returns the academyCoachDevelopmentManager
    }
}, 
    
    ACADEMYMANAGER {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new academyManager (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "academyManager"; //returns the academyManager
    }
},
    
    ASSTATHLETICTRAINER {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new asstAthleticTrainer (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "asstAthleticTrainer"; //returns the asstAthleticTrainer
    }
},
    
    ATTACKCOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new attackCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "attackCoach"; //returns the attackCoach
    }
},
    
    BACKCOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new backsCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "backsCoach"; //returns the backsCoach
    }
},
    
    DEFENCECOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new defenceCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "defenceCoach"; //returns the defenceCoach
    }
}, 
    
    
    FORWARDSCOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new forwardsCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "forwardsCoach"; //returns the forwardsCoach
    }
},
    
    HEADOfATHLETICPERFORMANCE {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new headOfAthleticPerformance (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "headOfAthleticPerformance"; //returns the headOfAthleticPerformance
    }
},
    
    HEADOFMEDICASERVICE {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new headOfMedicaService (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "headOfMedicaService"; //returns the headOfMedicaService
    }
},
    
    
    HEADOFMEDICAL {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new headOfMedical (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "headOfMedical"; //returns the headOfMedical
    }
},
    
    
    HEADOFRECRUITMENT {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new headOfRecruitment (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "headOfRecruitment"; //returns the headOfRecruitment
    }
},
    
    
    KICKINGCOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new kickingCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "kickingCoach"; //returns the kickingCoach
    }
},
   
    
    LEADPERFORMANCEANALYST {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new leadPerformanceAnalyst (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "leadPerformanceAnalyst"; //returns the leadPerformanceAnalyst
    }
},
    
    LEADPHYSIOLOTHERAPIST {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new leadPhysiolotherapist (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "leadPhysiolotherapist"; //returns the leadPhysiolotherapist
    }
},
    
   LINEOUTCOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new lineoutCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "lineoutCoach"; //returns the lineoutCoach
    }
}, 
   
   
   PERFORMANCEANALYST {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new performanceAnalyst (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "performanceAnalyst"; //returns the performanceAnalyst
    }
},
   
   PHYSIOTHERAPIST {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new physiotherapist (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "physiotherapist"; //returns the physiotherapist
    }
},
    
   SCRUMCOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new scrumCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "scrumCoach"; //returns the scrumCoach
    }
},
   
   SKILLSCOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new skillsCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "skillsCoach"; //returns the skillsCoach
    }
},
   
   STRENTHANDCONDITIONINGCOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new strenthAndConditioningCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "strenthAndConditioningCoach"; //returns the strenthAndConditioningCoach
    }
},
   
   TEAMMANAGER {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new teamManager (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "teamManager"; //returns the teamManager
    }
},
   
   WOMENHEADCOACH {
    
    @Override
    public coachingStaff getCoachingStaff() {
     
        this.sNameGenerator = new staffNameGenerator();
        String name = sNameGenerator.getRandomName();
        int hiredDate = 1;
        return new womenHeadCoach (name, getAge(), hiredDate);
        
    }
    
    @Override
    public String toString() {
        return "womenHeadCoach"; //returns the womenHeadCoach
    }
};
   
   protected staffNameGenerator sNameGenerator;
  public abstract coachingStaff getCoachingStaff();
  public abstract String toString();
  
  
  //methord to randomly generate user age
  private static int getAge() {
      
      Random r = new Random(); // random methord created
      
      return r.nextInt(70); //genarate the age until 70 
  }
   
   
}
