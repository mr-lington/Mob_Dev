/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coachingStaff;

/**
 *the properties of the coaching staffs is extended to all the coaching staffs
 * @author lington
 */
public abstract class coachingStaff {
     // properties of coachingStaff
    
    private String staffName;
    private int age;
    private int hiredDate;
    
    
    private coachingStaffType type;
    
    
    
   //constructor of coaching staff
    
    public coachingStaff (String staffName, int age, int hiredDate, coachingStaffType type){
        
        this.staffName = staffName;
        this.hiredDate = hiredDate;
        this.age = age;
        this.type = type;
    }
    
}
