/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coachingStaff;

import java.util.Random;

/**
 *
 * @author lington
 */
public class coachingStaffFactory {
    
    
    public coachingStaff getCoachingStaff() {
        
        Random r = new Random();
        coachingStaffType[] types = coachingStaffType.values();
        
        int number = r.nextInt(types.length);
        
        return getCoachingStaff(types[number]);
    }
    
    public coachingStaff getCoachingStaff(coachingStaffType type){
        
        return type.getCoachingStaff();
    }
    
}