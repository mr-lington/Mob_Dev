/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coachingStaff;

/**
 *
 * @author lington
 */
public class leadPerformanceAnalyst extends coachingStaff{
    
    public leadPerformanceAnalyst (String staffName, int age, int hiredDate){
        
        super(staffName, age, hiredDate, coachingStaffType.LEADPERFORMANCEANALYST);
    }
    
}
