/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coachingStaff;

/**
 *
 * @author lington
 */

     //the class are extended from the the class coachingStaff
public class  academyCoachDevelopmentManager extends coachingStaff {
    
    public academyCoachDevelopmentManager (String staffName, int age, int hiredDate){
        
        super(staffName, age, hiredDate, coachingStaffType.ACADEMYCOACHDEVELOPMENTMANAGER);
    }
}
